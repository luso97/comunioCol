function validatePasswordComunio(value){

if(value.lenght>12){
return "Las contraseñas no tienen mas de 12 caracteres";
}
return "";
}