<html>
<head>
</head>
<body>
<div>
<form method="post" action="createTeam2.php">
�Cu�ntos jugadores tiene el equipo?
<input type="text" name="num">
<input type="submit" value="crearEquipo">
</form>
</div>
</body>
</html>