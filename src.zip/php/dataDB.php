<?php

function createConn(){
	$server='localhost';
$database='comunio';
$user='admin';
$password='admin';
	$conn = new mysqli($server, $user, $password, $database);
	return $conn;
}
?>