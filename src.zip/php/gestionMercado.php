<html>
	<head>
		
	</head>
	<body>
		<div class="row">
			<div class="col-6">
				<a href="mercadoCerrar.php">Cerrar Mercado y abrir nuevo</a>
				<a href="recargarMercado.php">Recargar de jugadores mercado</a>
				
			</div>
		</div>
	</body>
</html>