<?php 
session_start();
require_once("../php/dataDB.php");
$idJC=$_REQUEST['jugador'];
$idOFerta=$_REQUEST['idOferta'];
$conn=createConn();
$query="UPDATE OFERTAS SET ACEPTADA=1 WHERE IDOFERTA=$idOFerta";
$conn->query($query);
$query="update OFERTAS set aceptada=0 where idoferta!=$idOFerta and idJugCom=$idJC";
$conn->query($query);
header('Location:mercado.php');
?>
