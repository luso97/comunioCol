<?php
session_start();
require_once ("../php/dataDB.php");
?>
<html>
	<head>
		<meta name="viewport" content="width=device-width,intial-scale=1.0">
		<link rel="stylesheet" href="../css/main.css">
	</head>
	<body>
		<?php

		include_once ("cabecera.php");
	?>
		<?php
	if (!isset($_SESSION['iduser'])) {
		header('Location:login.php');
	} else {
		$id = $_SESSION['iduser'];
	}
?>
<div class="row">
		<div class="col-5" style="float:left">
			<h4>
				Equipos
			</h4>
			<table class="col-5">
				<?php
$conn=createConn();
$query="SELECT * from equipoCom where iduser=$id";
$res=$conn->query($query);
foreach($res as $x){
				?>
				<tr>
					<form action="PrevistaGeneral.php" method="post">
						<input type="hidden" name="idEC" value=<?=$x['idEC']?>>
						<input type="hidden" name="idComunio" value=<?= $x['idComunio'] ?>>
					<td><?=$x['nombre'] ?></td><td><input type="submit" value="Ver"></td>
					</form>
				</tr>
				<?php
				}
				?>
			</table>

		</div>
			<div class="col-5" style="float:left">
				<h4>
					Comunios de los que eres admin
				</h4>
			<table class="col-5 tabla1">
				<?php
$conn=createConn();
$query="SELECT * from comunios where iduser=$id";
$res=$conn->query($query);
foreach($res as $x){
				?>
				<tr>
					<form action="vistaGeneral.php" method="post">
						<input type="hidden" name="idEC" value=<?=$x['idComunio']?>>
					<td><?=$x['name'] ?></td><td><input type="submit" value="Ver"></td>
					</form>
				</tr>
				<?php
				}
				?>
				
			</table>

		</div>
		<div class="col-3" style="padding-top: 13%">
			<form method="post" action="addComunio.php">
			Entrar en nuevo comunio (pon la contrase�a)<input type="password" name="passComunio"></br>
			Entrar el nombre de tu equipo en dicho comunio <input type="text" name="nombreEquipo"></br>
			<?php if(isset($_REQUEST['message'])){
				echo "No existe el comunio con dicha contrase�a";
			}
			?>
			<input type ="submit">
			</form>
		</div>
		<div class="col-4">
			<h3>Crear comunio</h3>
			<form action="crearComunio.php" method="get">
				Nombre<input type="text" name="name"></br>
				Contrase�a<input type="password" name="pass"></br>
				<input type="submit" value="Crear">
			</form>
			
		</div>
	</div>
	</body>
</html>