<?php
session_start();
require_once("../php/dataDB.php");
if(isset($_SESSION['idEC']) && isset($_SESSION['idComunio'])){
$idEC=$_SESSION['idEC'];
$idComunio=$_SESSION['idComunio'];

?>
<html>
	<head>
		<meta name="viewport" content="width=device-width,intial-scale=1.0">
		<link rel="stylesheet" href="../css/main.css">
	</head>
	<body>
		<div class="row">
			<?php
			include_once ("cabecera.php");
		?>
		<div>
			<table>
				<?php
				$conn = createConn();
				$query = "SELECT * from jugadores j,jugcom jc where j.idJugador=jc.idJugador and jc.idEquipo=$idEC ";
				$res = $conn -> query($query);
				?>
				<tr>
					<th>Jugador</th>
					<th>Posicion</th>
					<th>Valor</th>
					<th>Estado transferible</th>
					<th>Acciones</th>
				</tr>
				<?php
					foreach($res as $x){
						if ($x['mercado'] == 1) 
								$mess= "transferible";
							else 
								$mess="no transferible";
				?>
					<tr>
						<td><?=$x['nombre'] ?></td>
						<td><?=$x['posicion'] ?></td>
						<td><?=$x['valor'] ?></td>
						<td><?=$mess ?></td>
							
						
						<td>
							<form action="transferible.php" method="post">
								<input type="submit" value="Cambiar estado transferible">
								<input type="hidden" name="id" value=<?=$x['idJC']?>>
							</form>
						</td>
					</tr>
				<?php
						}
					?>

					


			</table>
		</div>
		</div>
	
	</body>
</html>
<?php 
}
?>